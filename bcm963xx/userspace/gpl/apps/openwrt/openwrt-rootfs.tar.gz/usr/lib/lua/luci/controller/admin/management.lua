module("luci.controller.admin.management", package.seeall)

function index()
	entry({"admin", "management"}, firstchild(), _("Management"), 70).index = true
	entry({"admin", "management", "tr69cfg"}, call("tr69_cfg"), _("TR-069 Client"), 10)
end

function tr69_cfg()
	local informP = luci.http.formvalue("inform")
	
	--Check if http get or post
	if informP then
		local dbus = require "dbus"
		local cwmpCall
		local inform = "boolean:"..informP
		local informInterval = "uint32:"..luci.http.formvalue("informInterval")
		local acsURL = "string:"..luci.http.formvalue("acsURL")  
		local acsUser = "string:"..luci.http.formvalue("acsUser")  
		local acsPwd = "string:"..luci.http.formvalue("acsPwd")  
		local debug = "boolean:"..luci.http.formvalue("debug") 
		local noneConnReqAuth = "boolean:"..luci.http.formvalue("noneConnReqAuth")
		local connReqUser = "string:"..luci.http.formvalue("connReqUser") 
		local connReqPwd = "string:"..luci.http.formvalue("connReqPwd")

		--Sarah: hard code wan interface to any_wan
		cwmpCall = dbus.sysCall("com.broadcom.DataAdaptation", "/com/broadcom/DataAdaptation", 
							"com.broadcom.DataAdaptation.CwmpClient", "SetCwmpClientConfigration", 
							{inform, informInterval, acsURL, acsUser, acsPwd, "string:Any_WAN", 
							 debug, noneConnReqAuth, connReqUser, connReqPwd})
							
		if cwmpCall[1] ~= 0 then
		luci.template.render("error500", {
			message = luci.i18n.translate(cwmpCall[2]),
		})

		return
		end
	end		
	
	luci.template.render("admin_management/tr69cfg")
end

